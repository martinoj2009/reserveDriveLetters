﻿#
# This script will compare current drive letters, and compare them against reserved drive letters
# Martino Jones
# 20150807
#


#Get a list of current drives
$drives = @((GET-WMIOBJECT win32_logicaldisk | where {$_.ProviderName -notlike "\\*"}).DeviceID).replace(":", "")


#List of drives we want to reserve
$reservedDriveLetters = @("h", "a", "b", "g", "i", "s", "t", "y", "x")

#Get colliding drive letters, use Compare, too lazy to make loop within loop ;-)
$collide = @(Compare-Object -ReferenceObject $reservedDriveLetters -DifferenceObject $drives -IncludeEqual | where {$_.SideIndicator -eq "=="})

#Get available drive letters
$availableLetters = @(ls function:[d-z]: -n | ?{ !(test-path $_) })

#Change the letter for collide drive(s)
for($i = 0; $i -lt $collide.Length; $i++)
{
	$driveLetter = $collide[$i].InputObject + ":"
	#I don't know how to pop array with fixed size, this will just count up from the bottom
	$newDriveLetter = $availableLetters[-($i+1)]

	$drive = gwmi win32_volume -Filter "DriveLetter = '$driveLetter'"
	$drive.DriveLetter = "$newDriveLetter"
	$drive.put()
}
# SIG # Begin signature block
# MIII9AYJKoZIhvcNAQcCoIII5TCCCOECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUJFX0d9+Wtg2CF7Tp8zeUIDx8
# O6KgggZgMIIGXDCCBUSgAwIBAgIKaxtxPAADAAAaozANBgkqhkiG9w0BAQUFADBP
# MRMwEQYKCZImiZPyLGQBGRYDb3JnMRYwFAYKCZImiZPyLGQBGRYGd2NjbmV0MRIw
# EAYKCZImiZPyLGQBGRYCaXMxDDAKBgNVBAMTA2NhMTAeFw0xNTA3MzExOTM3MTla
# Fw0xNzA3MzAxOTM3MTlaMHcxEzARBgoJkiaJk/IsZAEZFgNvcmcxFjAUBgoJkiaJ
# k/IsZAEZFgZ3Y2NuZXQxEjAQBgoJkiaJk/IsZAEZFgJpczEMMAoGA1UECxMDV0ND
# MQ4wDAYDVQQLEwVTdGFmZjEWMBQGA1UEAxMNTWFydGlubyBKb25lczCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBANSGbG1+yf+n1XjH7i1a4bSlxjoFqECL
# ZH4DKObonu2vShRlt/NADYih+2JcZSsRLd4uLMOZ7Eggur65NUX9Ug+rjEiqZdT6
# GXMDlHKkReRiehJTiEw/9X+8DI8L2arn7Kn0E5zcJpNrzsFhz7GReWk7gldSx3Dm
# ASAT/CAC2xLacdk1f1Zxb8Vs2G52I/Fi6Zy6bLAoVN/EtojWiX6BR78G17Sd/sRh
# euEU4mJTtoMN8cqkHxLFYxzjPzAxfz1TWsJ1U4o4TWXJikh+1D8YQvTsSCitHjsw
# 9fqIH5axMsH6CZtuhJ8x0+RFm/fpKoyLyQzLQpxL6e60FZCS357yyOcCAwEAAaOC
# AxAwggMMMD0GCSsGAQQBgjcVBwQwMC4GJisGAQQBgjcVCIGPmnGDnJxOhaGTDIGq
# 0TOFrLpZgTiDzY1jyfhcAgFkAgEEMBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1Ud
# DwQEAwIHgDAbBgkrBgEEAYI3FQoEDjAMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBT4
# pq7BwAkeRChuAoi13gQ2+CXnxTAfBgNVHSMEGDAWgBQGtC2i8E+WiFwfOzrza046
# 6wXYMjCB9wYDVR0fBIHvMIHsMIHpoIHmoIHjhoGvbGRhcDovLy9DTj1jYTEoMyks
# Q049dGV2byxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2Vy
# dmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1pcyxEQz13Y2NuZXQsREM9b3JnP2Nl
# cnRpZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0
# cmlidXRpb25Qb2ludIYvaHR0cDovL3Rldm8uaXMud2NjbmV0Lm9yZy9DZXJ0RW5y
# b2xsL2NhMSgzKS5jcmwwggEKBggrBgEFBQcBAQSB/TCB+jCBpwYIKwYBBQUHMAKG
# gZpsZGFwOi8vL0NOPWNhMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2Vydmlj
# ZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1pcyxEQz13Y2NuZXQs
# REM9b3JnP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0
# aW9uQXV0aG9yaXR5ME4GCCsGAQUFBzAChkJodHRwOi8vdGV2by5pcy53Y2NuZXQu
# b3JnL0NlcnRFbnJvbGwvdGV2by5pcy53Y2NuZXQub3JnX2NhMSgzKS5jcnQwRAYD
# VR0RBD0wO6AlBgorBgEEAYI3FAIDoBcMFW1ham9uZXNAaXMud2NjbmV0Lm9yZ4ES
# bWFqb25lc0B3Y2NuZXQuZWR1MA0GCSqGSIb3DQEBBQUAA4IBAQBkIozoFsueFYXj
# opv2hI7isngQyA1/v0gTQmWeyfG70G8N2wUuHGKe9ojPcU1au/Si0HdWE3ufriG8
# A82lt9jtbNNjl/gvZXnGmzgG6nJFgEMmiVAuLsngjCD+BFrNfxbAKyyU15ivTqox
# qdI8BVEQngC9nA1ssrSUGAcFXd5RxIvcALGOjrMH1SST9n5WNcDqGBGmi3YFZUuC
# XDG2YSVw6S6el4GuZSnBqyMJazQCRrlxBU9tfMlcYzPN6VUQh/giIe2LYM7J4sQr
# R7DVlgp8XtTG6uAuSdlzgyN3LHRAAoTA6Dbf1yzqSYdb0JBo/qNksp77MxpyZamG
# kmXc6p0ZMYIB/jCCAfoCAQEwXTBPMRMwEQYKCZImiZPyLGQBGRYDb3JnMRYwFAYK
# CZImiZPyLGQBGRYGd2NjbmV0MRIwEAYKCZImiZPyLGQBGRYCaXMxDDAKBgNVBAMT
# A2NhMQIKaxtxPAADAAAaozAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUnop3QJvNx8yShrhW6awF
# BItHaiswDQYJKoZIhvcNAQEBBQAEggEAwyQEVJS8na0bUvZ0Im/OBSiiZyAP+iVM
# rHANTR7nd3YSsGTQmlRJfHHa149nrNh0pw/D7URdVF/bkC8vcI12rMVrDlv5B7DE
# YUpcllJH0i1euQpwRqDEkStCDYTsKgbOXnGUsHSbmw/NuZCB52NqB2Zx7RRs/IJ6
# BjFTuHA0AfwLbE43YRyS6yuyry6O4BVy8TXLqgRn5+iI79Fo0UMEX1WTNPxJesIj
# D8DNYwaZU+olIYYEQQNQkD1ByZDNNeyyCxRbow+2fHZcfsES6y3V9fHVZUbfvhLu
# wi2+irrNevYxZZPOATo8HIuTlsz8NXL8XsXZJVN37oHez8IBuG4cgg==
# SIG # End signature block
